import smoothScroll from 'smooth-scroll';

smoothScroll('a[href*="#"]', { easing: 'linear' });
