var data = {
    listOfWork: [
        {
            img: "k_f_2019.jpg",
            textLink: "k_f_2019",
            textProject: "Консольная утилита фронтендера на стажировку в СКБ Контур. NodeJS",
            link: "https://github.com/alte0/k_f_2019/"
        },
        {
            img: "card-game.jpg",
            textLink: "Card-game Vuejs",
            textProject: "Карточная игра. SPA на Vuejs, переделано 10.18г.",
            link: "https://github.com/alte0/cards-game-vuejs/"
        },
        {
            img: "pixel-hunter.jpg",
            textLink: "pixel-hunter",
            textProject: "Личный проект в HtmlAcademy. JS 2",
            link: "https://alte0.github.io/43745-pixel-hunter/"
        },
        {
            img: "Whitewill.jpg",
            textLink: "Тестовое на вакансию",
            textProject:
                "Тестовое на вакансию. Pug, SCSS, БЭМ, Javascript, Gulp IE10+",
            link: "https://alte0.github.io/Whitewill-test/"
        },
        {
            img: "card-game.jpg",
            textLink: "Card-game",
            textProject: "Карточная игра. Pug, Stylus, БЭМ, Javascript",
            link: "https://alte0.github.io/cards-game/"
        },
        {
            img: "Main_Company.jpg",
            textLink: "Тестовое на вакансию",
            textProject:
                "Тестовое на вакансию.Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6, IE10+",
            link: "https://alte0.github.io/Main_Company/"
        },
        {
            img: "keksobooking.jpg",
            textLink: "keksobooking",
            textProject: "Личный проект в HtmlAcademy. JS 1",
            link: "https://alte0.github.io/43745-keksobooking/"
        },
        {
            img: "kosmetika-proff.jpg",
            textLink: "kosmetika-proff",
            textProject:
                "Из фиксированной в адаптивную.Верстка в команде. IE10+",
            link: "https://kosmetika-proff.ru/"
        },
        {
            img: "mypolis.jpg",
            textLink: "mypolis.pro",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE10+",
            link: "http://mypolis.online/"
        },
        {
            img: "it-stok24.jpg",
            textLink: "it-stok24",
            textProject:
                'Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE9+ страницы "О компании" и "Доставка и оплата"',
            link: "http://www.it-stok24.ru/"
        },
        {
            img: "just2trade.jpg",
            textLink: "just2trade",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде.IE9+ множество разных страниц",
            link: "https://just2trade.online/solutions/bitcoin2"
        },
        {
            img: "dizelkompleks.jpg",
            textLink: "dizelkompleks",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE10+ страница подбора электростанции",
            link: "https://dizelkompleks.ru/about/station-selection/"
        },
        {
            img: "stm32dent.jpg",
            textLink: "32 Дент стоматология",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE10+",
            link: "http://stm32dent.ru/"
        },
        {
            img: "remstroicom.jpg",
            textLink: "remstroicom",
            textProject:
                "API Yandex.Map - кластиризация обьктов на карте, JSON",
            link: "http://remstroicom.ru/objects/?display=map/"
        },
        {
            img: "champsplanet.jpg",
            textLink: "Центр силового катания",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE10+",
            link: "http://champsplanet.ru"
        },
        {
            img: "paketville.jpg",
            textLink: "Пакет вилль",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, Foundation 6. Верстка отдельных страниц в команде. IE9+",
            link: "http://paketville.ru/"
        },
        {
            img: "24pet.jpg",
            textLink: "24pet",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, Foundation 6. Верстка отдельных страниц под адаптив, с сохранением дизайна в команде. IE9+",
            link: "https://24pet.ru/"
        },
        {
            img: "hcnh.jpg",
            textLink: "ХК Нефтехимик",
            textProject:
                "Pug, SCSS, БЭМ, Gulp, jQuery plugins, Foundation 6. Верстка в команде. IE10+",
            link: "http://www.hcnh.ru/"
        },
        {
            img: "n-family.jpg",
            textLink: "n-family",
            textProject:
                "Pug(ex.Jade), Pre - Processor - SCSS, БЭМ, GRUNT, jQuery v3.1, jQuery plugins, Bootstrap 4 grid, CSS Анимация, Адаптация под разные разрешения экрана",
            link: "https://alte0.github.io/n-family/"
        },
        {
            img: "brandi.jpg",
            textLink: "brandi",
            textProject:
                "Pug(ex.Jade), Pre - Processor - { Less }, БЭМ, Task Runner - GRUNT, jQuery v3.1, API Яндекс.Карт, CSS Анимация, Brandi адаптивен под разные разрешения экрана",
            link: "https://alte0.github.io/brandi/"
        },
        {
            img: "BAccessibility.jpg",
            textLink: "BAccessibility",
            textProject:
                "Перевод плагина для CMS Joomla на русский язык и модификация под сайт",
            link: "https://github.com/alte0/mod_baccessibility"
        },
        {
            img: "bibl-omut_ru.jpg",
            textLink: "МАУ ЦИБМО",
            textProject:
                "CMS Joomla, Bootstrap 3, шаблон Helix 3, Плагины минификации кода",
            link: "https://bibl-omut.ru"
        }
    ]
};
