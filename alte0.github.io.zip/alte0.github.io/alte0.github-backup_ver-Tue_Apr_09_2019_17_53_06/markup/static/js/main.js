'use strict';

/*
    This file can be used as entry point for webpack!
 */
require('./plugins/smooth-scroll-plugin');
