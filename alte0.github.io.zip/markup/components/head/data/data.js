head: {
    defaults: {
        title: 'HTML-верстальщик: Максим Дмитриев',
        useSocialMetaTags: false
    }
}
