var data = {skillsList: [
    'HTML5 (form attr, nav, section...)', 'CSS3 (flexbox, transition, animate)', 'Pug (ex.Jade)', 'LESS', 'SASS', 'Stylus', 'БЭМ', 'SVG', 'спрайты', 'Gulp', 'Grunt', 'немного webpack', 'NPM', 'Bower', 'Yarn', 'jQuery', 'JavaScript', 'GSAP (небольшой опыт)', 'Git (Github.com, Bitbucket.org, Gitlab)', 'Bootstrap', 'Foundation', 'адаптивная, кроссбраузерная, валидная -  вёрстка', 'Jira'
]};
