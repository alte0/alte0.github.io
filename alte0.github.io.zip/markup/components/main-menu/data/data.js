mainMenu: {
    data: [
        { link: '#about', text: 'Обо мне', classIcon: 'link_icon-about' },
        { link: '#education', text: 'Образование', classIcon: 'link_icon-education' },
        { link: '#portfolio', text: 'Портфолио', classIcon: 'link_icon-portfolio' },
        {
            link:
                'https://tyumen.hh.ru/resume/2c50f0daff033630930039ed1f7a795a6f4e6c',
            text: 'Я на hh.ru',
            targetBlank: true,
            classIcon: 'link_icon-hh'
        },
        {
            link:
                'https://htmlacademy.ru/profile/alte0',
            text: 'Я на htmlacademy.ru',
            targetBlank: true,
            classIcon: 'link_icon-htmlacademy'
        },
        {
            link:
                'mailto:makc-dmv@yandex.ru',
            text: 'makc-dmv@yandex.ru',
            targetBlank: true,
            classIcon: 'link_icon-email'
        },
        {
            link:
                'https://telegram.me/Alte0',
            text: 'Telegram @Alte0',
            targetBlank: true,
            classIcon: 'link_icon-telegram'
        },
        {
            link:
                'skype:ctpagateji@yandex.ru?chat',
            text: 'Skype',
            targetBlank: true,
            classIcon: 'link_icon-skype'
        },
        {
            link:
                'https://github.com/alte0',
            text: 'Github',
            targetBlank: true,
            classIcon: 'link_icon-github'
        }
    ]
}
