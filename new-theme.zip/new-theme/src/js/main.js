import svg4everybody from 'svg4everybody'
import { initSmoothScroll } from './components/smooth-scroll'

svg4everybody()
initSmoothScroll()
// require('./components/components')
