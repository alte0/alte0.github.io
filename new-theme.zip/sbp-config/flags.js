module.exports = {
  minify: false,
  bs: true,
  watch: true
}
