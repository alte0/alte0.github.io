import smoothScroll from 'smooth-scroll'

export const initSmoothScroll = function () {
  smoothScroll('a[href*="#"]', { easing: 'linear', speed: 300, speedAsDuration: true })
}
